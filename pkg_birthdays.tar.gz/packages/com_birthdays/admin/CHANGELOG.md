CHANGELOG
=============

Este arquivo refere-se às mudanças realizadas desde a versão inicial de desenvolvimento.

* 2.0.0 - 26/04/2015
  * Added - Instução para remoção de arquivos obsoletos
  * Added - Script para renderização de campos de formulário
  * Updated - Atualização de data de copyright nos arquivos
  * Message - Migração do componente e módulo compatível com Joomla 3.x
  * Updated - Conteúdo do arquivo README.md
  * Added - Arquivo CHANGELOG.md com modidicações sofridas pelo pacote
  * Added - Arquivo de licenciamento do pacote, componente e módulo
* 1.0.2 -
  * Fixed - Exibição de lista de aniversários com data diferente do banco
  * Removed - Uppercase no campo nome
  * Fixed - Campos do tipo data no formulário
  * Fixed - Campo data de nascimento modificado para formato DATETIME
* 1.0.1 -
  * Updated - Campo data de nascimento modificado para formato DATE
  * Fixed - Corrigido problema na criação de novos aniversários
  * Updated - Ordem de apresentação de aniversários por dia

* 1.0.0 - 19/12/2012
  * Message - Primeira versão funcional
  * Message - Estruturação do pacote