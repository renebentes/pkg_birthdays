Birthdays - pkg_birthdays
=============

Pacote de extensão Joomla para Gerenciamento de Aniversários.

* Componente: com_birthdays
* Módulo: mod_birthdays_month

Requirements
------------

* [Joomla! 3.2+](http://www.joomla.org)

Author
------

[Rene Bentes Pinto](http://github.com/renebentes)

License
--------

* This package licensed under the terms of the [GNU/GPLv2](http://github.com/renebentes/pkg_birthdays/blob/master/packages/com_birthdays/LICENSE) license.

Bugs/Requests
-------------

You can [report a bug or request a feature here](http://github.com/renebentes/pkg_birthdays/issues)

TODO
----



Release Notes
-------------

You can [see the release notes here](http://github.com/renebentes/pkg_birthdays/blob/master/packages/com_birthdays/CHANGELOG.md)